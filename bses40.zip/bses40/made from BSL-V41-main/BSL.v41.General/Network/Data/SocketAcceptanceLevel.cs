﻿namespace BSL.v41.General.Network.Data;

public enum SocketAcceptanceLevel
{
    NowOpened = 1,
    ClosingStage = 2,
    NowClosed = 3,
    OpeningStage = 4
}