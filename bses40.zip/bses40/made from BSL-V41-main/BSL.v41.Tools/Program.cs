﻿using BSL.v41.Titan.Graphic;

namespace BSL.v41.Tools;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'Tools' has been launched.");
    }
}