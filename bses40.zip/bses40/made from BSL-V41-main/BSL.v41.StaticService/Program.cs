﻿using BSL.v41.Titan.Graphic;

namespace BSL.v41.StaticService;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd,
            "Emulation of 'StaticService' has been launched.");
    }
}