﻿namespace BSL.v41.Custom.Stream.Proxy.Laser;

public class DataField
{
    public required string FieldType { get; set; }
    public required string FieldValue { get; set; }
}