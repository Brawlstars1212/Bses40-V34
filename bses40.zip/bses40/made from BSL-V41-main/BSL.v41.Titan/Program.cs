﻿using BSL.v41.Titan.Graphic;

namespace BSL.v41.Titan;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'Titan' has been launched.");
    }
}